
Oracle NoSQL Database examples

This directory contains a number of Java example programs that can be compiled
and run with Oracle NoSQL Database.  These examples use the java direct driver
which is downloadable from: 
  https://www.oracle.com/database/technologies/nosql-database-server-downloads.html

For more information and instructions for use, see the example javadoc:
  https://docs.oracle.com/en/database/other-databases/nosql-database/22.1/examples/index.html

on the product documentation page:
  https://docs.oracle.com/en/database/other-databases/nosql-database/22.1/
