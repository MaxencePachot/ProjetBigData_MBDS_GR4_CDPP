/*-
 * Copyright (C) 2011, 2022 Oracle and/or its affiliates. All rights reserved.
 *
 * This file was distributed by Oracle as part of a version of Oracle NoSQL
 * Database made available at:
 *
 * http://www.oracle.com/technetwork/database/database-technologies/nosqldb/downloads/index.html
 *
 * Please see the LICENSE file included in the top-level directory of the
 * appropriate version of Oracle NoSQL Database for a copy of the license and
 * additional information.
 */

package table;

import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicReference;

import oracle.kv.table.Index;
import oracle.kv.table.IndexKey;
import oracle.kv.table.Row;
import oracle.kv.table.Table;
import oracle.kv.table.TableAPI;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

/**
 * Example: Asynchronous API
 *
 * <p>This example demonstrates using the asynchronous table API to put rows
 * into a table and then iterate over the rows using an index.
 */
public class AsyncExample extends BaseExample {

    /**
     * Sample input data: names and instruments.
     */
    private static String[] INPUT_DATA = {
        "Vladimir Horowitz", "piano",
        "John Coltrane", "tenor sax",
        "McCoy Tyner", "piano",
        "Jimmy Garrison", "bass",
        "Elvin Jones", "drums",
        "Isidore Cohen", "violin",
        "Bernard Greenhouse", "cello",
        "Menahem Pressler", "piano",
        "Eric Clapton", "guitar",
        "Jack Bruce", "bass",
        "Ginger Baker", "drums",
        "Arthur Rubinstein", "piano",
        "Jacob Collier", "voice",
        "Miles Davis", "trumpet",
        "Wayne Shorter", "tenor sax",
        "Herbie Hancock", "piano",
        "Ron Carter", "bass",
        "Tony Williams", "drums",
        "Glenn Gould", "piano"
    };

    private volatile Table table;
    private volatile TableAPI tableAPI;

    /**
     * A semaphore to wait for an operation to complete.
     */
    private final Semaphore awaitDone = new Semaphore(0);

    /**
     * Stores the exception that terminated the last operation, or null.
     */
    private final AtomicReference<Throwable> failure =
        new AtomicReference<Throwable>();

    @Override
    public String getShortDescription() {
        return "Async API Example";
    }

    @Override
    public void setup() {
        executeDDL("CREATE TABLE IF NOT EXISTS musicians " +
                   "(name STRING, " +
                   " instrument STRING, " +
                   " PRIMARY KEY (name))");

        System.out.println("Creating index instruments");
        executeDDL("CREATE INDEX IF NOT EXISTS instruments ON " +
                   "musicians(instrument)");

        table = getTable("musicians");
        tableAPI = getTableAPI();
    }

    @Override
    public void teardown() {
        executeDDL("DROP INDEX IF EXISTS instruments ON musicians");
        executeDDL("DROP TABLE IF EXISTS musicians");
    }

    @Override
    public Void call() {
        insert(INPUT_DATA, 0);
        awaitDone("Insert");
        iterate();
        awaitDone("Iterate");
        return null;
    }

    /** Insert rows into the table */
    private void insert(final String[] data, final int offset) {
        if (offset >= data.length) {
            awaitDone.release();
            return;
        }
        if ((data.length - offset) < 2) {
            failure.set(
                new IllegalArgumentException("Need even number of items"));
            awaitDone.release();
            return;
        }
        final Row row = table.createRow();
        row.put("name", data[offset]).put("instrument", data[offset + 1]);
        tableAPI.putAsync(row, null, null)
            .whenCompleteAsync((result, ex) -> {
                    if (ex != null) {
                        failure.set(ex);
                        awaitDone.release();
                    } else {
                        insert(data, offset + 2);
                    }
                });
    }

    /**
     * Uses the index to iterate over a set of rows in the table.
     */
    private void iterate() {
        final Index index = table.getIndex("instruments");
        final IndexKey key = index.createIndexKey();
        key.put("instrument", "piano");
        tableAPI.tableIteratorAsync(key, null, null)
            .subscribe(new Subscriber<Row>() {
                private Subscription subscription;
                @Override
                public void onSubscribe(Subscription s) {
                    this.subscription = s;
                    subscription.request(1);
                }
                @Override
                public void onNext(Row row) {
                    System.out.println("Pianist: " +
                                       row.get("name").asString().get());
                    subscription.request(1);
                }
                @Override
                public void onComplete() {
                    awaitDone.release();
                }
                @Override
                public void onError(Throwable t) {
                    failure.set(t);
                    awaitDone.release();
                }
            });
    }

    /**
     * Waits an operation to complete.
     */
    private void awaitDone(String operation) {
        try {
            awaitDone.acquire(1);
        } catch (InterruptedException e) {
            failure.compareAndSet(null, e);
        }
        final Throwable e = failure.get();
        if (e == null) {
            System.out.println(operation + " completed successfully");
        } else if (e instanceof RuntimeException) {
            throw (RuntimeException) e;
        } else if (e instanceof Error) {
            throw (Error) e;
        } else {
            throw new RuntimeException("Unexpected exception: " + e, e);
        }
    }
}
